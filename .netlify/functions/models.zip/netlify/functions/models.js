var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/models.js
var models_exports = {};
__export(models_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(models_exports);

// lib/model-registry.js
var MODEL_REGISTRY = {
  chat: [
    {
      id: "gpt-5.4",
      name: "GPT-5.4 (Unfiltered)",
      provider: "openai",
      description: "GPT-5.4 \u2014 latest and most capable model, unfiltered mode",
      unfiltered: true
    },
    {
      id: "gpt-5.3",
      name: "GPT-5.3",
      provider: "openai",
      description: "GPT-5.3 \u2014 highly capable reasoning model"
    },
    {
      id: "gpt-5.2",
      name: "GPT-5.2",
      provider: "openai",
      description: "GPT-5.2 \u2014 advanced reasoning and generation"
    },
    {
      id: "gpt-5.1",
      name: "GPT-5.1",
      provider: "openai",
      description: "GPT-5.1 \u2014 next-generation language model"
    },
    {
      id: "gpt-4.1",
      name: "GPT-4.1",
      provider: "openai",
      description: "GPT-4.1 flagship model \u2014 great for complex tasks"
    },
    {
      id: "gpt-4.1-mini",
      name: "GPT-4.1 Mini",
      provider: "openai",
      description: "Fast and cost-efficient for everyday use"
    },
    {
      id: "gpt-4o",
      name: "GPT-4o",
      provider: "openai",
      description: "Multimodal model with vision and audio"
    },
    {
      id: "gpt-4o-mini",
      name: "GPT-4o Mini",
      provider: "openai",
      description: "Lightweight multimodal model"
    },
    {
      id: "nofilter-gpt",
      name: "NoFilter GPT",
      provider: "nofilter",
      description: "Unfiltered AI chat via NoFilter GPT API",
      unfiltered: true
    }
  ],
  image: [
    {
      id: "openai-image",
      name: "OpenAI Image",
      provider: "openai",
      description: "GPT Image generation via OpenAI"
    },
    {
      id: "gpt-image-1.5",
      name: "GPT Image 1.5",
      provider: "openai",
      modelId: "gpt-image-1.5",
      description: "GPT Image 1.5 \u2014 latest OpenAI image generation model"
    },
    {
      id: "flux",
      name: "Flux Image Generation",
      provider: "piapi"
    },
    {
      id: "leonardo",
      name: "Leonardo AI",
      provider: "leonardo",
      description: "High-quality image generation via Leonardo AI"
    },
    {
      id: "lucid-origin",
      name: "Lucid Origin",
      provider: "leonardo",
      modelId: "aa77f04e-3eec-4034-9c07-d0836e65191e",
      description: "Lucid Origin \u2014 photorealistic model via Leonardo AI"
    },
    {
      id: "seedream-4.5",
      name: "Seedream 4.5",
      provider: "leonardo",
      modelId: "b24e16ff-06e3-43eb-8d33-4416c2d75876",
      description: "Seedream 4.5 \u2014 vivid creative image generation via Leonardo AI"
    },
    {
      id: "nano-banana-2",
      name: "Nano Banana 2",
      provider: "leonardo",
      modelId: "e71a1c2f-4f80-4800-934f-2c68979d1cc6",
      description: "Nano Banana 2 \u2014 stylized image generation via Leonardo AI"
    },
    {
      id: "nofilter-image",
      name: "NoFilter Image",
      provider: "nofilter",
      description: "Unrestricted image generation via NoFilter GPT API"
    }
  ],
  video: [
    {
      id: "sora",
      name: "Sora Video",
      provider: "openai",
      description: "OpenAI Sora video generation"
    },
    {
      id: "runway-gen3",
      name: "Runway Gen-3 Video",
      provider: "runway"
    },
    {
      id: "kling-3.0",
      name: "Kling 3.0",
      provider: "kling",
      modelId: "kling-v3",
      description: "Kling 3.0 \u2014 high-quality video generation via Kling AI"
    },
    {
      id: "kling-omni",
      name: "Kling Omni",
      provider: "kling",
      modelId: "kling-omni",
      description: "Kling Omni \u2014 versatile video generation via Kling AI"
    },
    {
      id: "hailuo-2.3",
      name: "Hailuo 2.3",
      provider: "hailuo",
      modelId: "T2V-01",
      description: "Hailuo 2.3 \u2014 fast text-to-video generation via MiniMax"
    },
    {
      id: "veo-3.1",
      name: "Veo 3.1",
      provider: "google",
      modelId: "veo-3.1-generate-preview",
      description: "Veo 3.1 \u2014 cinematic video generation via Google"
    },
    {
      id: "nofilter-video",
      name: "NoFilter Video",
      provider: "nofilter",
      description: "Unrestricted video generation via NoFilter GPT API"
    }
  ],
  music: [
    {
      id: "suno",
      name: "Suno Music Generation",
      provider: "suno"
    }
  ],
  voice: [
    {
      id: "elevenlabs",
      name: "ElevenLabs Voice",
      provider: "elevenlabs"
    },
    {
      id: "openai_voice",
      name: "OpenAI Realtime Voice",
      provider: "openai"
    },
    {
      id: "nofilter-voice",
      name: "NoFilter Realtime Voice",
      provider: "nofilter",
      description: "Unfiltered realtime voice via NoFilter GPT API",
      unfiltered: true
    }
  ],
  realtime_voice: [
    {
      id: "marin",
      name: "Marin",
      provider: "openai",
      description: "Professional and expressive \u2014 exclusive to gpt-realtime"
    },
    {
      id: "cedar",
      name: "Cedar",
      provider: "openai",
      description: "Natural and conversational \u2014 exclusive to gpt-realtime"
    },
    {
      id: "alloy",
      name: "Alloy",
      provider: "openai",
      description: "Neutral and balanced voice"
    },
    {
      id: "echo",
      name: "Echo",
      provider: "openai",
      description: "Warm and engaging voice"
    },
    {
      id: "shimmer",
      name: "Shimmer",
      provider: "openai",
      description: "Energetic and expressive voice"
    }
  ]
};

// lib/_responses.js
var CORS_HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};
function fail(error, code = "ERR_UNKNOWN", statusCode = 500, extraHeaders) {
  return {
    statusCode,
    headers: { ...CORS_HEADERS, ...extraHeaders },
    body: JSON.stringify({ success: false, error, code })
  };
}
function preflight() {
  return { statusCode: 204, headers: CORS_HEADERS, body: "" };
}
function raw(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: { ...CORS_HEADERS, ...extraHeaders },
    body: JSON.stringify(body)
  };
}
var AI_STATE = Object.freeze({
  THINKING: "thinking",
  RESPONDING: "responding",
  DONE: "done"
});

// netlify/functions/models.js
async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return preflight();
  }
  if (event.httpMethod !== "GET") {
    return fail("Method not allowed", "ERR_METHOD", 405);
  }
  return raw(200, MODEL_REGISTRY);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
